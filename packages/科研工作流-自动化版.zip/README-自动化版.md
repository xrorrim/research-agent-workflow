# 科研多智能体工作流 · 自动化版（Claude Code 原生）

与手动接力版协议同源，两处架构变化：**消息总线由作者改为主会话**（全自动路由）；**角色1 并入主会话**——你打开 Claude Code 的那个对话就是和角色1 的对话，也是你与整个系统唯一的交流界面。

```
你(作者) ⇄ 主会话（角色1·调研者 + 消息总线）
                │ 自动派生/唤醒（无状态子代理）
    ┌───────────┼───────────┬───────────┐
    ▼           ▼           ▼           ▼
 role2       role3       role5       role4
 方向推进     实现与运行    检查者       结果汇总
                │
                └─ 正式运行由主会话后台启动（nohup + pid 文件），
                   与 role5 审核并行；审核不过 → kill 运行、清空结果、打回重做
```

为什么不需要 Python 编排器：Claude Code 原生支持在同一会话内派生子代理并与之通信（含 SendMessage 延续对话、并行派生、后台运行），拓扑与 Codex 同构（主会话为枢纽）。只有跨家混用（如 Claude Code 与 Codex 各担任部分角色）才需要外部总线——届时再找我写 Python 版。

## 一句话安装（推荐）

把 zip 放进你的项目仓库根目录，对 Claude Code 说：

```
解压 科研工作流-自动化版.zip 到当前目录，然后按 BOOTSTRAP.md 执行。
```

它会自己完成文件放置、建目录骨架、检查 git 并汇报验证清单，然后当场变身为角色1 向你要课题。以下手动三步是等价备选。

## 手动安装（3 步）

1. 把文件放进你的项目仓库：

   | 文件 | 放到 |
   |------|------|
   | `CLAUDE.md` | 仓库根目录（Claude Code 自动加载） |
   | `role2-strategist.md`、`role3-implementer.md`、`role4-logbook.md`、`role5-reviewer.md` | `.claude/agents/` |
   | `settings.json` | `.claude/`（主会话模型配置；已有同名文件则合并 `model` 与 `effortLevel` 两个键） |

2. 建目录骨架：

   ```bash
   mkdir -p .claude/agents docs/route_archive logbook/messages experiments results tests
   touch logbook/index.md logbook/debt.md
   ```

3. 版本要求：Claude Code **v2.1.219 或更新**。zip 包解压到仓库根目录即完成第 1、2 步。

## 模型分层

算力向决策与实现倾斜，审核与记录降一级（优先开发、弱化安检）：

| 角色 | model | effort | 配置在 |
|------|-------|--------|--------|
| 角色1（主会话·调研者） | `best` | `xhigh` | `.claude/settings.json` |
| 角色2 方向推进者 | `best` | `max` | agent frontmatter |
| 角色3 实现与运行者 | `best` | `max` | agent frontmatter |
| 角色5 检查者 | `opus` | `max` | agent frontmatter |
| 角色4 结果汇总者 | `opus` | `max` | agent frontmatter |

**用的是别名不是模型 ID**：`best` = 有权限就用当前最强模型（截至 2026-07 为 Fable 5），否则自动回落到最新 Opus；`opus` = 最新 Opus（现为 Opus 5）。模型换代时两个别名自动跟随，不用改任何文件；也意味着没有 Fable 权限的人 clone 下来照样能跑，只是顶层降为 Opus。

要改分层，改这两处即可：`.claude/settings.json` 的 `model` 键（角色1）、四个 agent 文件 frontmatter 的 `model:` 行。

**三个坑**：

- **主会话的 effort 只能到 `xhigh`**。`max` 是会话级设置，`settings.json` 不接受。想让角色1 也跑 `max`，每次开会话手动 `/effort max`。子代理不受此限——frontmatter 的 `effort: max` 正常生效，且优先级高于会话级设置。
- **不要开 ultracode**。它不是模型深度档位，而是"`xhigh` + 让 Claude 自动编排 dynamic workflow"。本工作流已有自己的状态机（R2→R3→R5→R4），两套编排会打架。它也写不进 frontmatter 或 `settings.json`——只能 `/effort ultracode` 或 `--effort ultracode`，仅当前会话有效。
- **`CLAUDE_CODE_EFFORT_LEVEL` 环境变量会压过一切**，包括 frontmatter。设了它，模型分层里的 effort 部分全部失效。

## 使用

1. 在仓库目录启动 `claude`，直接描述你的课题——对面就是角色1，会做深度调研并与你多轮讨论；
2. 你确认路线后，它写好 `docs/route.md`、发出 M1，说"**开始循环**"即进入全自动实验循环；
3. 之后它只在这些时刻找你：**M7 路线上报**（假设证伪 / 连续 3 循环无进展 / 每 5 循环例行对照偏离）、**判死路线需你确认**、**达标结题**。你随时可以主动发话，优先级最高；
4. 会话中断后，新开会话说"**继续循环**"，它会从 `logbook/messages/` 恢复断点（状态全在文件里，不依赖会话记忆）。

## 循环内自动发生什么（对照协议 M1–M7）

| 消息 | 方向 | 内容 |
|------|------|------|
| M1 | 角色1 → R2 | 路线下达 |
| M2 | R2 → R3 | 任务下达（含可测量的验收标准） |
| M3 | R3 → R5 | 审核请求（含 commit、run.sh、预计时长；无新代码免审） |
| M4 | R5 → R3 | 审核结果；不通过 → 主会话 kill 运行、清空本循环结果、打回重做（3 次上限） |
| M5 | R3 → R4 | 结果交付（失败也如实交付，3 次运行失败上限） |
| M6 | R4 → R2 | 笔记归档 + **合规判定**（有无偷工减料、实验不对齐、数字不可溯源；不通过则 R2 决定补救） |
| M7 | R2 → 角色1 | 路线上报（此时系统暂停找你讨论） |

全部消息原文自动存档在 `logbook/messages/`，人类可读的实验笔记在 `logbook/cycle_NNN.md`，全局记忆在 `logbook/index.md`，工程债（安全加固/系统补全等，一律留给你人工处理）在 `logbook/debt.md`。

## 成本与运行建议

- 每个循环 = 5–8 次子代理调用 + 主会话轮询，token 消耗可观；建议先用小任务跑 1–2 个循环观察质量再放长。
- 每 5 个循环亲自读一遍 `logbook/index.md`（与 M7 例行对照同频），确认方向没有漂移。
- 主会话上下文过长时可 `/compact`——协议设计上状态全在文件里，压缩不丢状态。

## 配置开关

- **改回"先审后跑"（串行）**：CLAUDE.md 状态机第 3 步，改为先唤醒 role5-reviewer、M4 通过后再启动运行（文件内有注明）。
- 审核打回上限、运行失败上限（各 3 次）、例行对照周期（5 循环）均为 CLAUDE.md 中的明文数字，按需修改。
